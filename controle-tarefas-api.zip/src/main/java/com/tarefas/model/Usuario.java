
package com.tarefas.model;

import javax.persistence.*;
import java.util.List;

@Entity
public class Usuario {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nome;
    private String email;
    private String senha;
    private String nivelPrioridade;  // Ex: Alta, Média, Baixa

    @OneToMany(mappedBy = "usuario")
    private List<Tarefa> tarefas;

    @OneToMany(mappedBy = "usuario")
    private List<Categoria> categorias;

    // Getters e Setters
}
